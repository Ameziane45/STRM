/* Champs de Recherche */
const searchWrapper = document.querySelector(".search-container");
const closeBtn = document.querySelector(".fa-times");

// Event Bouton Recherche
searchWrapper.addEventListener("click", () => {
    searchWrapper.classList.add("active");
});

closeBtn.addEventListener("click", (event) => {
    event.stopImmediatePropagation();
    searchWrapper.classList.remove("active");
});