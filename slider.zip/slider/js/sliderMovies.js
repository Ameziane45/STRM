
// Event - Carousel Film
let skipBtn = document.querySelectorAll(".skip");
let listMovies = document.querySelectorAll(".list__movies");

skipBtn.forEach((skipBtn, i) => {
    const itemNumber = listMovies[i].querySelectorAll(".img__movie").length;
    let clickCounter = 0;
    skipBtn.addEventListener("click", () => {
        const ratio = Math.floor(window.innerWidth / 270);
        clickCounter++;
        if (itemNumber - (4 + clickCounter) + (4 - ratio) >= 0) {
        listMovies[i].style.transform = `translateX(${listMovies[i].computedStyleMap().get("transform")[0].x.value - 300
            }px)`;
        } else {
        listMovies[i].style.transform = "translateX(0)";
        clickCounter = 0;
        }
    });
    
    console.log(Math.floor(window.innerWidth / 270));
    }); 